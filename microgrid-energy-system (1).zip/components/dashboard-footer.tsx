"use client"

import { Battery, BarChart3, Zap, Network } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import Link from "next/link"

interface DashboardFooterProps {
  activeTab?: "generation" | "storage" | "consumption" | "distribution"
}

export function DashboardFooter({ activeTab = "generation" }: DashboardFooterProps) {
  const tabs = [
    { id: "generation", label: "Generation", icon: Zap, href: "/dashboard" },
    { id: "storage", label: "Storage", icon: Battery, href: "/storage" },
    { id: "consumption", label: "Consumption", icon: BarChart3, href: "/consumption" },
    { id: "distribution", label: "Distribution", icon: Network, href: "/distribution" },
  ]

  return (
    <footer className="bg-card border-t border-border px-6 py-4">
      <nav className="flex justify-center">
        <div className="flex gap-2">
          {tabs.map((tab) => {
            const Icon = tab.icon
            const isActive = activeTab === tab.id
            return (
              <Link key={tab.id} href={tab.href}>
                <Button
                  variant={isActive ? "default" : "ghost"}
                  className={cn(
                    "flex flex-col gap-1 h-auto py-3 px-6",
                    isActive && "bg-primary text-primary-foreground",
                  )}
                >
                  <Icon className="h-5 w-5" />
                  <span className="text-xs">{tab.label}</span>
                </Button>
              </Link>
            )
          })}
        </div>
      </nav>
    </footer>
  )
}
